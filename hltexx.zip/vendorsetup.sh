add_lunch_combo cm_hltexx-eng

